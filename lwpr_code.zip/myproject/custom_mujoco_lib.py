import mujoco
import numpy as np

def serial_joint_control(model_path, full_target_qpos,
                         wait_time=10000,
                         stable_threshold=1e-5,
                         stable_required_steps=10,
                         seed=None):
    """
    控制每个 joint 单独移动，直到稳定。若中途发生碰撞或超时，则提前返回。

    Returns:
        final_qpos: np.ndarray, 实际最终关节位置
        delta_qpos: np.ndarray, 与目标关节的偏差
        status_code: int
            0 -> 成功稳定
            1 -> 超时（某个关节未在 wait_time 内稳定）
            2 -> 控制过程中发生碰撞
    """
    model = mujoco.MjModel.from_xml_path(model_path)
    data = mujoco.MjData(model)
    nq = model.nq
    assert len(full_target_qpos) == nq, "Target qpos length must match number of joints."

    if seed is not None:
        np.random.seed(seed)

    data.qpos[:] = 0.0
    data.qvel[:] = 0.0
    mujoco.mj_resetData(model, data)
    mujoco.mj_forward(model, data)

    for joint_idx in range(nq):
        current_target = data.qpos.copy()
        current_target[joint_idx] = full_target_qpos[joint_idx]

        stable_count = 0
        prev_qpos = data.qpos.copy()

        for step in range(wait_time):
            data.qpos[:] = current_target
            data.qvel[:] = 0.0
            mujoco.mj_step(model, data)

            # ✅ 检查碰撞
            if data.ncon > 0:
                return data.qpos.copy(), data.qpos.copy() - full_target_qpos, int(2)  # 2 = collision

            curr_qpos = data.qpos.copy()
            joint_diffs = np.abs(curr_qpos - prev_qpos)

            if np.all(joint_diffs < stable_threshold):
                stable_count += 1
            else:
                stable_count = 0

            if stable_count >= stable_required_steps:
                break

            prev_qpos = curr_qpos.copy()
        else:
            return data.qpos.copy(), data.qpos.copy() - full_target_qpos, int(1)  # 1 = timeout

    return data.qpos.copy(), data.qpos.copy() - full_target_qpos, int(0)  # 0 = success


def test_serial_control():
    model_path = "/home/bt/mu/mujoco-3.3.3/model/franka_sim-master/franka_panda.xml"

    model = mujoco.MjModel.from_xml_path(model_path)
    nq = model.nq
    jnt_ranges = model.jnt_range[:nq]

    np.random.seed()
    full_target_qpos = np.random.uniform(jnt_ranges[:, 0], jnt_ranges[:, 1])
    print(f"\n🎯 Full target qpos:\n{full_target_qpos}")

    final_qpos, delta_qpos, status_code = serial_joint_control(
        model_path=model_path,
        full_target_qpos=full_target_qpos,
        wait_time=10000,
        stable_threshold=1e-6,
        stable_required_steps=10
    )

    if status_code == 1:
        print("❌ Aborted: Timed out waiting for stability.")
        return
    elif status_code == 2:
        print("❌ Aborted: Collision detected during execution.")
        return

    max_error = np.max(np.abs(delta_qpos))

    print("\n=======================")
    print("✅ All joints finished.")
    print("=======================")
    print("🎯 Target qpos:")
    print(full_target_qpos)
    print("\n📏 Final actual qpos:")
    print(final_qpos)
    print("\n📉 Difference (actual - target):")
    print(delta_qpos)
    print(f"\n🚨 Max absolute joint error: {max_error:.4e}")

import mujoco
import numpy as np
from scipy.spatial.transform import Rotation as R

def extract_ee_pose(model_path, qpos):
    """
    给定关节位置 qpos，计算并返回末端执行器的 6D 位姿（位置 + 旋转向量）

    Args:
        model_path: str, MJCF 模型路径
        qpos: np.ndarray, nq维关节位置向量

    Returns:
        ee_pose: np.ndarray, shape (6,), 前3维为position，后3维为旋转向量
    """
    model = mujoco.MjModel.from_xml_path(model_path)
    data = mujoco.MjData(model)

    if len(qpos) != model.nq:
        raise ValueError("qpos length does not match model.nq")

    # 设定状态并 forward
    data.qpos[:] = qpos
    data.qvel[:] = np.zeros_like(data.qvel)
    mujoco.mj_forward(model, data)

    # 获取末端执行器 site ID
    ee_site_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_SITE, "end_effector")
    if ee_site_id < 0:
        raise ValueError("Cannot find 'end_effector' site in model.")

    ee_pos = data.site_xpos[ee_site_id].copy()               # shape (3,)
    ee_mat = data.site_xmat[ee_site_id].reshape(3, 3).copy() # shape (3, 3)

    # 转为旋转向量（axis-angle）
    ee_rotvec = R.from_matrix(ee_mat).as_rotvec()            # shape (3,)
    ee_pose = np.concatenate([ee_pos, ee_rotvec])            # shape (6,)

    return ee_pose

def test_extract_ee_pose():
    model_path = "/home/bt/mu/mujoco-3.3.3/model/franka_sim-master/franka_panda.xml"

    # 随机目标姿态
    model = mujoco.MjModel.from_xml_path(model_path)
    nq = model.nq
    jnt_ranges = model.jnt_range[:nq]
    target_qpos = np.random.uniform(jnt_ranges[:, 0], jnt_ranges[:, 1])

    # 执行关节控制
    final_qpos, delta_qpos, status_code = serial_joint_control(
        model_path=model_path,
        full_target_qpos=target_qpos,
        wait_time=10000,
        stable_threshold=1e-6,
        stable_required_steps=10
    )

    if status_code != 0:
        print(f"❌ Control failed with status code {status_code}")
        return

    # 提取末端执行器位姿
    ee_pose = extract_ee_pose(model_path, final_qpos)

    print("\n=============================")
    print("📍 Extracted End-Effector Pose")
    print("=============================")
    print(f"Position     : {ee_pose[:3]}")
    print(f"Orientation  : {ee_pose[3:]} (rotvec)")
    print("=============================")


if __name__ == "__main__":
    test_serial_control()
    test_extract_ee_pose()

