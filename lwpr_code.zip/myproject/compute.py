import numpy as np
import mujoco
from mujoco_stable import MujocoStableSampler

model_path = "/home/bt/mu/mujoco-3.3.3/model/franka_sim-master/franka_panda.xml"
sampler = MujocoStableSampler(model_path=model_path)

n_joints = sampler.model.nq
joint_ranges = sampler.model.jnt_range[:n_joints]

samples = []
num_samples = 2000  # 越多越准确
for i in range(num_samples):
    q = np.random.uniform(joint_ranges[:, 0], joint_ranges[:, 1])
    sampler.data.qpos[:] = q
    sampler.data.qvel[:] = 0.0
    mujoco.mj_forward(sampler.model, sampler.data)
    sampler.wait_until_stable()
    ee_pose = sampler.sample_after_stable()["ee_pose"]
    ee_pos = np.asarray(ee_pose).flatten()[:3]
    samples.append(ee_pos)
    print('now is',i)

samples = np.array(samples)
x_bounds = (samples[:, 0].min(), samples[:, 0].max())
y_bounds = (samples[:, 1].min(), samples[:, 1].max())
z_bounds = (samples[:, 2].min(), samples[:, 2].max())

print("\n📐 Estimated Workspace Bounds:")
print(f"  x: {x_bounds}")
print(f"  y: {y_bounds}")
print(f"  z: {z_bounds}")
