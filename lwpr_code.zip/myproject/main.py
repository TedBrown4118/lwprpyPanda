import numpy as np
import os
import mujoco
from custom_mujoco_lib import serial_joint_control, extract_ee_pose

class DeltaSampler:
    def __init__(self, model_path, num_tasks=10000, delta_scale=0.15,
                 workspace_bounds=None):
        self.model_path = model_path
        self.model = mujoco.MjModel.from_xml_path(model_path)
        self.data = mujoco.MjData(self.model)
        self.n_joints = self.model.nq
        self.joint_ranges = self.model.jnt_range[:self.n_joints]
        self.num_tasks = num_tasks
        self.delta_scale = delta_scale

        self.ee_site_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, "end_effector")
        self.workspace_bounds = workspace_bounds  # should be passed in explicitly now
        if self.workspace_bounds is None:
            raise ValueError("Workspace bounds must be provided explicitly.")

        self.delta_qpos_list = self.generate_deltas()
        self.current_qpos = np.zeros(self.n_joints)
        self.ee_pose_prev = None

        self.delta_qpos_inputs = []
        self.delta_qpos_outputs = []
        self.delta_qvel_outputs = []
        self.delta_ee_outputs = []
        self.failed_tasks = []

        self.save_dir = os.path.join(os.path.dirname(__file__), "data_collected", "task2")
        os.makedirs(self.save_dir, exist_ok=True)

    def generate_deltas(self):
        np.random.seed(123)
        joint_range_span = self.joint_ranges[:, 1] - self.joint_ranges[:, 0]
        return np.random.uniform(
            low=-joint_range_span * self.delta_scale,
            high=joint_range_span * self.delta_scale,
            size=(self.num_tasks, self.n_joints)
        )

    def run(self):
        for i, delta in enumerate(self.delta_qpos_list):
            print(f"\n🔄 Executing ΔTask {i+1}/{self.num_tasks}")
            target_qpos = self.current_qpos + delta
            target_qpos = np.clip(target_qpos, self.joint_ranges[:, 0], self.joint_ranges[:, 1])

            final_qpos, _, status = serial_joint_control(
                model_path=self.model_path,
                full_target_qpos=target_qpos,
                wait_time=10000,
                stable_threshold=1e-6,
                stable_required_steps=10
            )

            if int(status) != 0:
                self.failed_tasks.append(delta[:7])
                print("❌ Task skipped: failed to stabilize.")
                continue

            # Extract EE pose at current qpos after reaching target
            ee_pose_curr = extract_ee_pose(self.model_path, final_qpos)

            # First sample, just initialize state
            if self.ee_pose_prev is None:
                self.current_qpos[:7] = final_qpos[:7]
                self.ee_pose_prev = ee_pose_curr
                print("⚠️ Skipped first sample (no previous ee pose to compute delta).")
                continue

            # Compute delta values
            dqpos = final_qpos[:7] - self.current_qpos[:7]
            dqvel = np.zeros(7)
            delta_ee = ee_pose_curr - self.ee_pose_prev

            self.delta_qpos_inputs.append(delta[:7])
            self.delta_qpos_outputs.append(dqpos)
            self.delta_qvel_outputs.append(dqvel)
            self.delta_ee_outputs.append(delta_ee)

            # Update previous states
            self.current_qpos[:7] = final_qpos[:7]
            self.ee_pose_prev = ee_pose_curr
            print("✅ ΔSample collected.")

        self.save_all()

    def save_all(self):
        np.savetxt(os.path.join(self.save_dir, "delta_input.csv"), np.array(self.delta_qpos_inputs), delimiter=",")
        np.savetxt(os.path.join(self.save_dir, "delta_qpos.csv"), np.array(self.delta_qpos_outputs), delimiter=",")
        np.savetxt(os.path.join(self.save_dir, "delta_qvel.csv"), np.array(self.delta_qvel_outputs), delimiter=",")
        np.savetxt(os.path.join(self.save_dir, "delta_ee_pose.csv"), np.array(self.delta_ee_outputs), delimiter=",")

        if self.failed_tasks:
            np.savetxt(os.path.join(self.save_dir, "delta_failed.csv"), np.array(self.failed_tasks), delimiter=",")

        print(f"\n📦 Delta Task Data saved in {self.save_dir}")
        print(f"✅ Success: {len(self.delta_qpos_inputs)}")
        print(f"❌ Failures: {len(self.failed_tasks)}")


if __name__ == "__main__":
    model_path = "/home/bt/mu/mujoco-3.3.3/model/franka_sim-master/franka_panda.xml"
    workspace_bounds = {
        'x': (-0.7693733321094557, 0.7929312041853592),
        'y': (-0.34207398246704157, 0.16506661883051288),
        'z': (0.035370159416271, 1.0721558056548322)
    }
    task_sampler = DeltaSampler(model_path=model_path, num_tasks=100, delta_scale=0.15,
                                workspace_bounds=workspace_bounds)
    task_sampler.run()
