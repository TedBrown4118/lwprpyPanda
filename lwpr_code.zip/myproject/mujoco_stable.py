import numpy as np
import mujoco
from collections import deque
from scipy.spatial.transform import Rotation as R

class MujocoStableSampler:
    def __init__(self, model_path, stability_window=100, stability_thresh=None):
        self.model_path = model_path
        self.model = mujoco.MjModel.from_xml_path(model_path)
        self.data = mujoco.MjData(self.model)
        self.stability_window = stability_window
        self.stability_thresh = stability_thresh or self._estimate_stability_thresh()

        # 查找末端执行器 site
        self.ee_site_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, "end_effector")
        if self.ee_site_id == -1:
            raise ValueError("Cannot find site named 'end_effector'")

    def _estimate_stability_thresh(self, steps=1000):
        prev = self.data.qpos.copy()
        diffs = []
        temp_data = mujoco.MjData(self.model) 
        for _ in range(steps):
            mujoco.mj_step(self.model, temp_data)
            curr = temp_data.qpos.copy()
            diffs.append(np.linalg.norm(curr - prev))
            prev = curr
        return np.mean(diffs) * 0.3

    def wait_until_stable(self, target_qpos=None, max_steps=50000, check_qvel=True, check_ee=True, ee_thresh=1e-4):
        if target_qpos is None:
            raise ValueError("You must provide a target_qpos for stability check.")

        joint_range_span = self.model.jnt_range[:self.model.nq, 1] - self.model.jnt_range[:self.model.nq, 0]
        tolerance = 0.1

        for step in range(max_steps):
            mujoco.mj_step(self.model, self.data)

            # ✅ 碰撞检测：立即中止
            if self.data.ncon > 0:
                print(f"❌ Collision detected at step {step}.")
                return False

            # ✅ 检查每个关节误差是否在容差内
            qpos_error = np.abs(self.data.qpos[:self.model.nq] - target_qpos)
            within_tolerance = np.all(qpos_error < tolerance)

            qvel_mag = np.linalg.norm(self.data.qvel)
            ee_stable = True

            # ✅ 可选：末端执行器移动量
            if check_ee:
                ee_pos = self.data.site_xpos[self.ee_site_id].copy()
                mujoco.mj_step(self.model, self.data)
                ee_pos_next = self.data.site_xpos[self.ee_site_id].copy()
                ee_diff = np.linalg.norm(ee_pos_next - ee_pos)
                ee_stable = ee_diff < ee_thresh
            else:
                ee_diff = 0.0

            if within_tolerance and (not check_qvel or qvel_mag < 1e-4) and ee_stable:
                print(f"✅ Stable at step {step}, max qpos_error = {np.max(qpos_error):.3e}, qvel = {qvel_mag:.3e}, Δee = {ee_diff:.3e}")
                return True

        print("⚠️ Did not stabilize within max steps.")
        print('details are')
        print("📉 Target qpos was:")
        print(target_qpos)
        print("📉 Actual qpos at last step was:")
        print(self.data.qpos.copy())
        return False






    def sample_after_stable(self, sample_steps=100):
        positions = []
        velocities = []
        ee_positions = []
        ee_orientations = []

        for _ in range(sample_steps):
            mujoco.mj_step(self.model, self.data)
            positions.append(self.data.qpos.copy())
            velocities.append(self.data.qvel.copy())
            ee_positions.append(self.data.site_xpos[self.ee_site_id].copy())
            ee_orientations.append(self.data.site_xmat[self.ee_site_id].copy())

        # 转为 numpy 数组
        positions = np.array(positions)
        velocities = np.array(velocities)
        ee_positions = np.array(ee_positions)
        ee_orientations = np.array(ee_orientations).reshape(-1, 3, 3)

        # 取平均
        avg_position = np.mean(positions, axis=0)
        avg_velocity = np.mean(velocities, axis=0)
        avg_ee_position = np.mean(ee_positions, axis=0)
        avg_ee_orientation = np.mean(ee_orientations, axis=0)

        # 姿态转换为旋转向量（axis-angle）
        rotvec = R.from_matrix(avg_ee_orientation).as_rotvec()  # shape (3,)

        # 拼成一个 6D pose 向量
        ee_pose = np.concatenate([avg_ee_position, rotvec])  # shape (6,)

        return {
            "qpos": avg_position,
            "qvel": avg_velocity,
            "ee_pose": ee_pose  # 3D position + 3D orientation (rotvec)
        }
    
    def print_joint_limits(self):
            print("🔍 Joint angle limits:")
            for i in range(self.model.njnt):
                name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_JOINT, i)
                joint_type = self.model.jnt_type[i]
                limits = self.model.jnt_range[i]
                print(f" - {name} | type={joint_type} | range=({limits[0]:.3f}, {limits[1]:.3f})")

def test_sampler(model_path):
            print("🔧 Initializing MujocoStableSampler...")
            try:
                sampler = MujocoStableSampler(model_path)
            except Exception as e:
                print(f"❌ Initialization failed: {e}")
                return

            print("🧪 Checking end effector site ID:", sampler.ee_site_id)

            print("⏳ Estimating stability threshold...")
            thresh = sampler.stability_thresh
            if np.isnan(thresh) or thresh <= 0:
                print(f"❌ Invalid stability threshold: {thresh}")
                return
            print(f"✅ Stability threshold estimated: {thresh:.3e}")

            print("⏱ Waiting for system to stabilize...")
            if not sampler.wait_until_stable():
                print("❌ System did not stabilize.")
                return
            print("✅ System stabilized.")

            print("📦 Sampling stable state...")
            sample = sampler.sample_after_stable()

            print("\n=== Sample Output ===")
            for key, val in sample.items():
                print(f"{key}: shape = {val.shape}, dtype = {val.dtype}")
                if np.any(np.isnan(val)):
                    print(f"⚠️  {key} contains NaNs!")
                elif np.any(np.isinf(val)):
                    print(f"⚠️  {key} contains Infs!")
                else:
                    print(f"✅  {key} is valid.")

            print("\n🎉 All tests completed.")
