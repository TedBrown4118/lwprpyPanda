import numpy as np
import os
import mujoco
from mujoco_stable import MujocoStableSampler

class DeltaSampler:
    def __init__(self, model_path, num_tasks=10000, delta_scale=0.15,
                 workspace_bounds=None):
        self.sampler = MujocoStableSampler(model_path=model_path)
        self.n_joints = self.sampler.model.nq
        self.joint_ranges = self.sampler.model.jnt_range[:self.n_joints]
        self.num_tasks = num_tasks
        self.delta_scale = delta_scale

        self.ee_site_id = self.sampler.ee_site_id
        self.workspace_bounds = workspace_bounds  # should be passed in explicitly now
        if self.workspace_bounds is None:
            raise ValueError("Workspace bounds must be provided explicitly.")

        self.delta_qpos_list = self.generate_deltas()
        self.current_qpos = np.zeros(self.n_joints)

        self.delta_qpos_inputs = []
        self.delta_qpos_outputs = []
        self.delta_qvel_outputs = []
        self.delta_ee_outputs = []
        self.failed_tasks = []

        self.save_dir = os.path.join(os.path.dirname(__file__), "data_collected", "task2")
        os.makedirs(self.save_dir, exist_ok=True)

    def generate_deltas(self):
        np.random.seed(123)
        joint_range_span = self.joint_ranges[:, 1] - self.joint_ranges[:, 0]
        return np.random.uniform(
            low=-joint_range_span * self.delta_scale,
            high=joint_range_span * self.delta_scale,
            size=(self.num_tasks, self.n_joints)
        )

    def is_feasible(self, target_qpos, actual_qpos=None):
        feasible = True
        margin = 0.01 * (self.joint_ranges[:, 1] - self.joint_ranges[:, 0])

        mujoco.mj_forward(self.sampler.model, self.sampler.data)
        if self.sampler.data.ncon > 0:
            print("❌ Collision detected.")
            feasible = False

        check_qpos = actual_qpos if actual_qpos is not None else target_qpos

        near_limits = (check_qpos < self.joint_ranges[:, 0] + margin) | \
                      (check_qpos > self.joint_ranges[:, 1] - margin)
        if np.any(near_limits):
            print("❌ Joint configuration too close to limit.")
            for j in range(self.n_joints):
                if near_limits[j]:
                    print(f"  Joint {j}: target={target_qpos[j]:.4f}, actual={check_qpos[j]:.4f}, limit=({self.joint_ranges[j,0]:.4f}, {self.joint_ranges[j,1]:.4f})")
            feasible = False

        return feasible

    def run(self):
        for i, delta in enumerate(self.delta_qpos_list):
            print(f"\n🔄 Executing ΔTask {i+1}/{self.num_tasks}")
            target_qpos = self.current_qpos + delta
            target_qpos = np.clip(target_qpos, self.joint_ranges[:, 0], self.joint_ranges[:, 1])

            self.sampler.data.qpos[:] = self.current_qpos
            self.sampler.data.qvel[:] = 0.0
            mujoco.mj_resetData(self.sampler.model, self.sampler.data)
            mujoco.mj_forward(self.sampler.model, self.sampler.data)

            try:
                ee_pose_before = self.sampler.sample_after_stable()["ee_pose"]
            except Exception as e:
                print(f"❌ Pre-stabilization failed: {e}")
                self.failed_tasks.append(delta)
                mujoco.mj_resetData(self.sampler.model, self.sampler.data)
                continue

            self.sampler.data.qpos[:] = target_qpos
            self.sampler.data.qvel[:] = 0.0
            mujoco.mj_resetData(self.sampler.model, self.sampler.data)
            mujoco.mj_forward(self.sampler.model, self.sampler.data)

            if not self.sampler.wait_until_stable(target_qpos=target_qpos):
                self.failed_tasks.append(delta)
                print("❌ Task skipped: did not stabilize.")
                mujoco.mj_resetData(self.sampler.model, self.sampler.data)
                continue

            mujoco.mj_forward(self.sampler.model, self.sampler.data)
            sample = self.sampler.sample_after_stable()
            actual_qpos = sample["qpos"]
            ee_pos = np.asarray(sample["ee_pose"]).flatten()

            print(f"🔍 Target qpos: {target_qpos}")
            print(f"🔍 Actual qpos: {actual_qpos}")

            if ee_pos.shape[0] < 3:
                print("❌ EE pose has fewer than 3 elements.")
                self.failed_tasks.append(delta)
                mujoco.mj_resetData(self.sampler.model, self.sampler.data)
                continue

            x, y, z = ee_pos[:3]
            if not (self.workspace_bounds['x'][0] <= x <= self.workspace_bounds['x'][1] and
                    self.workspace_bounds['y'][0] <= y <= self.workspace_bounds['y'][1] and
                    self.workspace_bounds['z'][0] <= z <= self.workspace_bounds['z'][1]):
                self.failed_tasks.append(delta)
                print("❌ EE pose out of workspace bounds.")
                mujoco.mj_resetData(self.sampler.model, self.sampler.data)
                continue

            if self.is_feasible(target_qpos, actual_qpos):
                dqpos = sample["qpos"] - self.current_qpos
                dqvel = sample["qvel"]
                dee = sample["ee_pose"] - ee_pose_before

                self.delta_qpos_inputs.append(delta)
                self.delta_qpos_outputs.append(dqpos)
                self.delta_qvel_outputs.append(dqvel)
                self.delta_ee_outputs.append(dee)

                self.current_qpos = sample["qpos"]
                print("✅ ΔSample collected.")
            else:
                self.failed_tasks.append(delta)
                print("❌ Task skipped due to feasibility failure.")
                mujoco.mj_resetData(self.sampler.model, self.sampler.data)

        self.save_all()

    def save_all(self):
        np.savetxt(os.path.join(self.save_dir, "delta_input.csv"), np.array(self.delta_qpos_inputs), delimiter=",")
        np.savetxt(os.path.join(self.save_dir, "delta_qpos.csv"), np.array(self.delta_qpos_outputs), delimiter=",")
        np.savetxt(os.path.join(self.save_dir, "delta_qvel.csv"), np.array(self.delta_qvel_outputs), delimiter=",")
        np.savetxt(os.path.join(self.save_dir, "delta_ee_pose.csv"), np.array(self.delta_ee_outputs), delimiter=",")

        if self.failed_tasks:
            np.savetxt(os.path.join(self.save_dir, "delta_failed.csv"), np.array(self.failed_tasks), delimiter=",")

        print(f"\n📦 Delta Task Data saved in {self.save_dir}")
        print(f"✅ Success: {len(self.delta_qpos_inputs)}")
        print(f"❌ Failures: {len(self.failed_tasks)}")


if __name__ == "__main__":
    model_path = "/home/bt/mu/mujoco-3.3.3/model/franka_sim-master/franka_panda.xml"
    workspace_bounds = {
        'x': (-0.7693733321094557, 0.7929312041853592),
        'y': (-0.34207398246704157, 0.16506661883051288),
        'z': (0.035370159416271, 1.0721558056548322)
    }
    task_sampler = DeltaSampler(model_path=model_path, num_tasks=5, delta_scale=0.15,
                                workspace_bounds=workspace_bounds)
    task_sampler.run()
